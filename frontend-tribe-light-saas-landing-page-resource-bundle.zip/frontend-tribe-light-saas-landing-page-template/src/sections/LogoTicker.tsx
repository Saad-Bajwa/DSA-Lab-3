export const LogoTicker = () => {
  return null;
};
