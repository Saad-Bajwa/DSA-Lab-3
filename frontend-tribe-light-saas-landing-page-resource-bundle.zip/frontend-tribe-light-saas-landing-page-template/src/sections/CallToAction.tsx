export const CallToAction = () => {
  return null;
};
