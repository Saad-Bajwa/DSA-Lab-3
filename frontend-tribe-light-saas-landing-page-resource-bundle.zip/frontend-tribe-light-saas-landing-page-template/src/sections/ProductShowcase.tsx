export const ProductShowcase = () => {
  return null;
};
